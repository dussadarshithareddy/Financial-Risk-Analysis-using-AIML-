#!/usr/bin/env python
"""Start the backend server without reload."""
import uvicorn
import os

if __name__ == "__main__":
    uvicorn.run(
        "app.main:app",
        host="127.0.0.1",
        port=8000,
        reload=False,
        log_level="info"
    )
